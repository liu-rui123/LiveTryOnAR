import ReplayKit
import SwiftUI

struct ReplayKitPreviewController: UIViewControllerRepresentable {
    let previewController: RPPreviewViewController
    let onClose: () -> Void

    func makeUIViewController(context: Context) -> RPPreviewViewController {
        previewController.previewControllerDelegate = context.coordinator
        return previewController
    }

    func updateUIViewController(_ uiViewController: RPPreviewViewController, context: Context) {}

    func makeCoordinator() -> Coordinator {
        Coordinator(onClose: onClose)
    }

    final class Coordinator: NSObject, RPPreviewViewControllerDelegate {
        private let onClose: () -> Void

        init(onClose: @escaping () -> Void) {
            self.onClose = onClose
        }

        func previewControllerDidFinish(_ previewController: RPPreviewViewController) {
            onClose()
        }
    }
}
