import ARKit
import SceneKit
import SwiftUI

struct FullBodyARTryOnView: UIViewControllerRepresentable {
    let topTexture: UIImage?
    let bottomTexture: UIImage?

    func makeUIViewController(context: Context) -> FullBodyARTryOnViewController {
        let controller = FullBodyARTryOnViewController()
        controller.coordinator.topTexture = topTexture
        controller.coordinator.bottomTexture = bottomTexture
        return controller
    }

    func updateUIViewController(_ controller: FullBodyARTryOnViewController, context: Context) {
        controller.coordinator.topTexture = topTexture
        controller.coordinator.bottomTexture = bottomTexture
        controller.coordinator.refreshTextures()
    }
}

final class FullBodyARTryOnViewController: UIViewController {
    let sceneView = ARSCNView(frame: .zero)
    let coordinator = FullBodyCoordinator()

    override func viewDidLoad() {
        super.viewDidLoad()
        sceneView.frame = view.bounds
        sceneView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        sceneView.delegate = coordinator
        sceneView.automaticallyUpdatesLighting = true
        sceneView.scene = SCNScene()
        view.addSubview(sceneView)

        guard ARBodyTrackingConfiguration.isSupported else {
            let label = UILabel()
            label.text = "此设备不支持完整 3D 人体追踪\n可切换到前置自拍模式。"
            label.numberOfLines = 0
            label.textAlignment = .center
            label.textColor = .white
            label.backgroundColor = UIColor.black.withAlphaComponent(0.65)
            label.layer.cornerRadius = 12
            label.clipsToBounds = true
            label.translatesAutoresizingMaskIntoConstraints = false
            view.addSubview(label)
            NSLayoutConstraint.activate([
                label.centerXAnchor.constraint(equalTo: view.centerXAnchor),
                label.centerYAnchor.constraint(equalTo: view.centerYAnchor),
                label.widthAnchor.constraint(lessThanOrEqualTo: view.widthAnchor, multiplier: 0.8)
            ])
            return
        }

        let configuration = ARBodyTrackingConfiguration()
        configuration.isAutoFocusEnabled = true
        sceneView.session.run(configuration, options: [.resetTracking, .removeExistingAnchors])
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        sceneView.session.pause()
    }
}

final class FullBodyCoordinator: NSObject, ARSCNViewDelegate {
    var topTexture: UIImage?
    var bottomTexture: UIImage?
    private weak var rig: OutfitRigNode?

    func renderer(_ renderer: SCNSceneRenderer, nodeFor anchor: ARAnchor) -> SCNNode? {
        guard let bodyAnchor = anchor as? ARBodyAnchor else { return nil }
        let root = SCNNode()
        let outfitRig = OutfitRigNode(topTexture: topTexture, bottomTexture: bottomTexture)
        root.addChildNode(outfitRig)
        outfitRig.update(from: bodyAnchor.skeleton)
        rig = outfitRig
        return root
    }

    func renderer(_ renderer: SCNSceneRenderer, didUpdate node: SCNNode, for anchor: ARAnchor) {
        guard let bodyAnchor = anchor as? ARBodyAnchor else { return }
        rig?.update(from: bodyAnchor.skeleton)
    }

    func refreshTextures() {
        rig?.setTextures(top: topTexture, bottom: bottomTexture)
    }
}

private final class OutfitRigNode: SCNNode {
    private let torso = OutfitRigNode.box(depth: 0.22)
    private let leftArm = OutfitRigNode.cylinder()
    private let rightArm = OutfitRigNode.cylinder()
    private let leftUpperLeg = OutfitRigNode.cylinder()
    private let rightUpperLeg = OutfitRigNode.cylinder()
    private let leftLowerLeg = OutfitRigNode.cylinder()
    private let rightLowerLeg = OutfitRigNode.cylinder()

    init(topTexture: UIImage?, bottomTexture: UIImage?) {
        super.init()
        [torso, leftArm, rightArm, leftUpperLeg, rightUpperLeg, leftLowerLeg, rightLowerLeg].forEach(addChildNode)
        setTextures(top: topTexture, bottom: bottomTexture)
    }

    required init?(coder: NSCoder) { nil }

    func setTextures(top: UIImage?, bottom: UIImage?) {
        apply(texture: top, fallback: .systemBlue, to: [torso, leftArm, rightArm])
        apply(texture: bottom, fallback: .systemIndigo, to: [leftUpperLeg, rightUpperLeg, leftLowerLeg, rightLowerLeg])
    }

    func update(from skeleton: ARSkeleton3D) {
        guard let leftShoulder = position(.leftShoulder, skeleton),
              let rightShoulder = position(.rightShoulder, skeleton),
              let leftHip = position(.leftUpLeg, skeleton),
              let rightHip = position(.rightUpLeg, skeleton) else { return }

        let shouldersCenter = (leftShoulder + rightShoulder) / 2
        let hipsCenter = (leftHip + rightHip) / 2
        torso.simdPosition = (shouldersCenter + hipsCenter) / 2
        torso.simdScale = SIMD3<Float>(
            max(0.25, simd_distance(leftShoulder, rightShoulder) * 1.20),
            max(0.35, simd_distance(shouldersCenter, hipsCenter) * 1.12),
            1
        )

        updateSegment(leftArm, from: leftShoulder, to: position(.leftHand, skeleton), radius: 0.11)
        updateSegment(rightArm, from: rightShoulder, to: position(.rightHand, skeleton), radius: 0.11)

        updateLeg(upper: leftUpperLeg, lower: leftLowerLeg, hip: leftHip, knee: position(.leftLeg, skeleton), ankle: position(.leftFoot, skeleton))
        updateLeg(upper: rightUpperLeg, lower: rightLowerLeg, hip: rightHip, knee: position(.rightLeg, skeleton), ankle: position(.rightFoot, skeleton))
    }

    private func updateLeg(upper: SCNNode, lower: SCNNode, hip: SIMD3<Float>, knee: SIMD3<Float>?, ankle: SIMD3<Float>?) {
        updateSegment(upper, from: hip, to: knee, radius: 0.14)
        updateSegment(lower, from: knee, to: ankle, radius: 0.12)
    }

    private func updateSegment(_ node: SCNNode, from start: SIMD3<Float>?, to end: SIMD3<Float>?, radius: Float) {
        guard let start, let end else { node.isHidden = true; return }
        let vector = end - start
        let length = simd_length(vector)
        guard length > 0.02 else { node.isHidden = true; return }
        node.isHidden = false
        node.simdPosition = (start + end) / 2
        node.simdScale = SIMD3<Float>(radius * 2, length, radius * 2)
        node.simdOrientation = simd_quatf(from: SIMD3<Float>(0, 1, 0), to: simd_normalize(vector))
    }

    private func position(_ joint: ARSkeleton.JointName, _ skeleton: ARSkeleton3D) -> SIMD3<Float>? {
        guard let transform = skeleton.modelTransform(for: joint) else { return nil }
        return SIMD3<Float>(transform.columns.3.x, transform.columns.3.y, transform.columns.3.z)
    }

    private func apply(texture: UIImage?, fallback: UIColor, to nodes: [SCNNode]) {
        nodes.compactMap { $0.geometry?.firstMaterial }.forEach { material in
            material.diffuse.contents = texture ?? fallback
            material.transparency = texture == nil ? 0.72 : 0.86
            material.isDoubleSided = true
            material.lightingModel = .physicallyBased
            material.roughness.contents = 0.65
        }
    }

    private static func box(depth: CGFloat) -> SCNNode {
        let geometry = SCNBox(width: 1, height: 1, length: depth, chamferRadius: 0.08)
        return SCNNode(geometry: geometry)
    }

    private static func cylinder() -> SCNNode {
        let geometry = SCNCylinder(radius: 0.5, height: 1)
        return SCNNode(geometry: geometry)
    }
}
