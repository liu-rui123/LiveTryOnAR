import SwiftUI

@main
struct LiveTryOnARApp: App {
    @StateObject private var outfitStore = OutfitStore()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(outfitStore)
        }
    }
}
