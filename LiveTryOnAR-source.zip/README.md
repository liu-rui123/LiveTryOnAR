# VESTRA Live Fit

纯本机 iPhone / iPad 实时试穿原型。导入一张同时包含上衣与裤装的商品图后，App 按图片上下区域裁剪贴图，并叠加到相机中的人体姿态或 ARKit 骨架上。

## 能力与限制

- 前置自拍：Vision 实时估计肩、髋、膝和脚踝，进行本地 2.5D 贴合。
- 完整 3D：后置相机使用 ARKit 人体骨架，将贴图映射到简化的 3D 身体模型；需要支持 ARKit Body Tracking 的设备。
- iPhone / iPad：分别适配窄屏单栏和宽屏侧边控制台。
- ReplayKit 屏幕录制：录下全屏相机预览和试穿叠层；停止后使用系统预览界面保存或分享。
- 图片不上传服务器。单张图片按上下区域裁切；复杂背景、模特图或服装不在上下排列时效果会受影响。
- 当前为贴图和简化模型原型，不包含布料物理模拟或生成式 VTO。

## GitHub 编译后通过全能签安装

1. 将此项目推送到 GitHub。
2. 打开仓库的 **Actions**，手动运行 **Build IPA for 全能签**。
3. 运行成功后下载 artifact：`LiveTryOnAR-unsigned-ipa`。
4. 解压得到 `LiveTryOnAR-unsigned.ipa`，导入全能签，选择自己的证书和描述文件签名，再按全能签流程安装。

此 workflow 只编译未签名 IPA，不需要将 `.p12` 证书或描述文件放进 GitHub。签名时所用证书和描述文件必须匹配 App 的 Bundle ID，且设备能否安装及签名有效期取决于该证书和描述文件。

可在 GitHub 仓库的 **Settings → Secrets and variables → Actions → Variables** 设置 `BUNDLE_IDENTIFIER`，并确保与签名描述文件的 App ID 匹配。未设置时使用 `com.example.LiveTryOnAR`。

## 在 Mac 上开发

需要 macOS、Xcode（iOS 17 SDK）和 XcodeGen：

```bash
brew install xcodegen
xcodegen generate --spec project.yml
open LiveTryOnAR.xcodeproj
```

也可以在 Mac 上直接运行 `bash Scripts/build_unsigned_ipa.sh`，生成的 IPA 位于 `build/ipa/`。Windows 无法运行 Xcode/iOS 编译。
