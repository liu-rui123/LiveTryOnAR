#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BUNDLE_ID="${BUNDLE_IDENTIFIER:-com.example.LiveTryOnAR}"
DERIVED_DATA="$ROOT_DIR/build/DerivedData"
PACKAGE_DIR="$ROOT_DIR/build/unsigned"
IPA_DIR="$ROOT_DIR/build/ipa"
APP_PATH="$DERIVED_DATA/Build/Products/Release-iphoneos/LiveTryOnAR.app"
IPA_PATH="$IPA_DIR/LiveTryOnAR-unsigned.ipa"

command -v xcodegen >/dev/null || { echo "xcodegen is required (brew install xcodegen)" >&2; exit 1; }
command -v xcodebuild >/dev/null || { echo "This script must run on macOS with Xcode installed." >&2; exit 1; }
command -v zip >/dev/null || { echo "zip is required." >&2; exit 1; }

xcodegen generate --spec "$ROOT_DIR/project.yml"
rm -rf "$DERIVED_DATA" "$PACKAGE_DIR" "$IPA_DIR"
mkdir -p "$PACKAGE_DIR/Payload" "$IPA_DIR"

xcodebuild \
  -project "$ROOT_DIR/LiveTryOnAR.xcodeproj" \
  -scheme LiveTryOnAR \
  -configuration Release \
  -sdk iphoneos \
  -derivedDataPath "$DERIVED_DATA" \
  CODE_SIGNING_ALLOWED=NO \
  CODE_SIGNING_REQUIRED=NO \
  CODE_SIGN_IDENTITY="" \
  PRODUCT_BUNDLE_IDENTIFIER="$BUNDLE_ID" \
  build

if [[ ! -d "$APP_PATH" ]]; then
  echo "Build succeeded but app bundle was not found: $APP_PATH" >&2
  exit 1
fi

ditto "$APP_PATH" "$PACKAGE_DIR/Payload/LiveTryOnAR.app"
(cd "$PACKAGE_DIR" && zip -qry "$IPA_PATH" Payload)
echo "Unsigned IPA ready for import and signing in 全能签: $IPA_PATH"
