import SwiftUI

enum TryOnMode: String, CaseIterable, Identifiable {
    case selfie = "前置自拍"
    case fullBodyAR = "完整 3D"

    var id: String { rawValue }

    var symbol: String {
        switch self {
        case .selfie: "camera.metering.center.weighted"
        case .fullBodyAR: "cube.transparent"
        }
    }

    var subtitle: String {
        switch self {
        case .selfie: "FRONT / LIVE POSE"
        case .fullBodyAR: "REAR / BODY TRACKING"
        }
    }

    var help: String {
        switch self {
        case .selfie:
            "前置相机实时捕捉肩、髋、膝盖与脚踝，适合自拍试穿。"
        case .fullBodyAR:
            "后置相机使用 ARKit 人体骨架追踪；请用支架或请他人持机拍全身。"
        }
    }
}

struct ContentView: View {
    @EnvironmentObject private var outfitStore: OutfitStore
    @State private var mode: TryOnMode = .selfie
    @State private var showPicker = false

    var body: some View {
        GeometryReader { proxy in
            let isWide = proxy.size.width >= 760

            ZStack {
                liveStage
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .ignoresSafeArea()

                if isWide {
                    HStack {
                        Spacer(minLength: 0)
                        controlDeck
                            .frame(width: 356)
                            .frame(maxHeight: proxy.size.height * 0.82)
                            .padding(.trailing, 22)
                    }
                    .padding(.vertical, 18)
                } else {
                    VStack {
                        Spacer(minLength: 0)
                        controlDeck
                            .frame(maxHeight: min(310, proxy.size.height * 0.40))
                            .padding(.horizontal, 14)
                            .padding(.bottom, 26)
                    }
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(SpaceBackground())
        }
        .preferredColorScheme(.dark)
        .statusBarHidden(true)
        .sheet(isPresented: $showPicker) {
            ProductImagePicker { image in
                outfitStore.setOutfitImage(image)
            }
            .preferredColorScheme(.dark)
        }
    }

    private var liveStage: some View {
        ZStack {
            Color.black

            Group {
                switch mode {
                case .selfie:
                    SelfieTryOnView(topTexture: outfitStore.topTexture, bottomTexture: outfitStore.bottomTexture)
                case .fullBodyAR:
                    FullBodyARTryOnView(topTexture: outfitStore.topTexture, bottomTexture: outfitStore.bottomTexture)
                }
            }

            LinearGradient(
                colors: [.clear, .black.opacity(0.08), .black.opacity(0.7)],
                startPoint: .center,
                endPoint: .bottom
            )
            .allowsHitTesting(false)

            HUDCornerMark()
                .padding(18)

            VStack {
                HStack {
                    LivePill()
                    Spacer()
                    Text(mode.subtitle)
                        .font(.system(size: 10, weight: .bold, design: .monospaced))
                        .tracking(1.2)
                        .foregroundStyle(.cyan.opacity(0.95))
                        .padding(.horizontal, 10)
                        .padding(.vertical, 7)
                        .background(.black.opacity(0.52), in: Capsule())
                }
                Spacer()
                HStack(alignment: .bottom) {
                    VStack(alignment: .leading, spacing: 5) {
                        Text(mode == .selfie ? "SELFIE FIT" : "SPATIAL FIT")
                            .font(.system(size: 18, weight: .heavy, design: .rounded))
                        Text(mode == .selfie ? "前置 2.5D 姿态贴合" : "后置 3D 骨架驱动")
                            .font(.caption.weight(.medium))
                            .foregroundStyle(.white.opacity(0.74))
                    }
                    Spacer()
                    VStack(spacing: 5) {
                        Image(systemName: "dot.radiowaves.left.and.right")
                        Text("TRACKING")
                            .font(.system(size: 9, weight: .bold, design: .monospaced))
                    }
                    .foregroundStyle(.mint)
                    .padding(10)
                    .background(.black.opacity(0.48), in: RoundedRectangle(cornerRadius: 12))
                }
            }
            .padding(20)
        }
    }

    private var controlDeck: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 16) {
                HStack {
                    Label("FIT CONSOLE", systemImage: "slider.horizontal.3")
                        .font(.system(size: 12, weight: .bold, design: .monospaced))
                        .tracking(1)
                        .foregroundStyle(.cyan)
                    Spacer()
                    Text("LOCAL AR")
                        .font(.system(size: 10, weight: .bold, design: .monospaced))
                        .foregroundStyle(.mint)
                }

                ConsoleSection(title: "CAMERA MODE", icon: "viewfinder") {
                    Picker("模式", selection: $mode) {
                        ForEach(TryOnMode.allCases) { value in
                            Label(value.rawValue, systemImage: value.symbol).tag(value)
                        }
                    }
                    .pickerStyle(.segmented)
                    Text(mode.help)
                        .font(.footnote)
                        .foregroundStyle(.white.opacity(0.68))
                        .fixedSize(horizontal: false, vertical: true)
                }

                ConsoleSection(title: "OUTFIT SOURCE", icon: "tshirt.fill") {
                    Button { showPicker = true } label: {
                        HStack(spacing: 10) {
                            Image(systemName: outfitStore.sourceImage == nil ? "plus.circle.fill" : "arrow.triangle.2.circlepath.circle.fill")
                                .font(.title3)
                            VStack(alignment: .leading, spacing: 2) {
                                Text(outfitStore.sourceImage == nil ? "导入成套商品图" : "替换当前套装")
                                    .font(.subheadline.weight(.bold))
                                Text("TOP + BOTTOM / ONE IMAGE")
                                    .font(.system(size: 9, weight: .bold, design: .monospaced))
                                    .foregroundStyle(.cyan.opacity(0.82))
                            }
                            Spacer()
                            Image(systemName: "chevron.right")
                                .font(.caption.weight(.bold))
                        }
                        .foregroundStyle(.white)
                        .padding(13)
                        .background(
                            LinearGradient(colors: [.cyan.opacity(0.27), .blue.opacity(0.13)], startPoint: .leading, endPoint: .trailing),
                            in: RoundedRectangle(cornerRadius: 14, style: .continuous)
                        )
                        .overlay {
                            RoundedRectangle(cornerRadius: 14, style: .continuous)
                                .stroke(.cyan.opacity(0.38), lineWidth: 1)
                        }
                    }
                    .buttonStyle(.plain)

                    if let image = outfitStore.sourceImage {
                        HStack(spacing: 12) {
                            Image(uiImage: image)
                                .resizable()
                                .scaledToFill()
                                .frame(width: 62, height: 78)
                                .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                                .overlay(RoundedRectangle(cornerRadius: 10).stroke(.white.opacity(0.17)))
                            VStack(alignment: .leading, spacing: 4) {
                                Text("套装贴图已同步")
                                    .font(.subheadline.weight(.semibold))
                                Text("图片上半部 → 上衣\n图片下半部 → 裤装")
                                    .font(.caption)
                                    .foregroundStyle(.white.opacity(0.58))
                            }
                            Spacer()
                            Image(systemName: "checkmark.seal.fill")
                                .foregroundStyle(.mint)
                        }
                        .padding(.top, 2)
                    } else {
                        StatusLine(icon: "sparkles", text: "尚未导入：使用默认霓虹蓝上衣与深色裤装")
                    }
                }

                ConsoleSection(title: "TRACKING TELEMETRY", icon: "dot.scope") {
                    HStack(spacing: 8) {
                        MetricCard(value: mode == .selfie ? "8" : "91", label: mode == .selfie ? "POSE POINTS" : "JOINTS")
                        MetricCard(value: "LIVE", label: "RENDER")
                        MetricCard(value: mode == .selfie ? "2.5D" : "3D", label: "FIT MODEL")
                    }
                    StatusLine(icon: "figure.walk", text: "请保持全身可见、光线充足；腿部需露出髋、膝和脚踝。")
                }

                HStack(spacing: 8) {
                    Image(systemName: "lock.shield.fill")
                        .foregroundStyle(.mint)
                    Text("镜头分析与试穿渲染均在设备本地完成")
                        .font(.caption2.weight(.medium))
                        .foregroundStyle(.white.opacity(0.57))
                }
                .padding(.horizontal, 2)
            }
            .padding(18)
        }
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 25, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 25, style: .continuous)
                .stroke(.white.opacity(0.13), lineWidth: 1)
        }
        .shadow(color: .black.opacity(0.35), radius: 20, y: 12)
    }
}

private struct ConsoleSection<Content: View>: View {
    let title: String
    let icon: String
    @ViewBuilder let content: Content

    var body: some View {
        VStack(alignment: .leading, spacing: 11) {
            Label(title, systemImage: icon)
                .font(.system(size: 10, weight: .bold, design: .monospaced))
                .tracking(0.9)
                .foregroundStyle(.white.opacity(0.56))
            content
        }
        .padding(14)
        .background(.black.opacity(0.24), in: RoundedRectangle(cornerRadius: 17, style: .continuous))
    }
}

private struct LivePill: View {
    var body: some View {
        HStack(spacing: 7) {
            Circle().fill(.red).frame(width: 7, height: 7)
            Text("LIVE")
                .font(.system(size: 10, weight: .heavy, design: .monospaced))
                .tracking(1)
        }
        .foregroundStyle(.white)
        .padding(.horizontal, 11)
        .padding(.vertical, 8)
        .background(.black.opacity(0.58), in: Capsule())
    }
}

private struct StatusLine: View {
    let icon: String
    let text: String

    var body: some View {
        Label {
            Text(text)
                .font(.caption)
                .foregroundStyle(.white.opacity(0.58))
        } icon: {
            Image(systemName: icon).foregroundStyle(.cyan)
        }
        .fixedSize(horizontal: false, vertical: true)
    }
}

private struct MetricCard: View {
    let value: String
    let label: String

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(value)
                .font(.system(size: 15, weight: .bold, design: .monospaced))
                .foregroundStyle(.mint)
            Text(label)
                .font(.system(size: 8, weight: .bold, design: .monospaced))
                .tracking(0.3)
                .foregroundStyle(.white.opacity(0.48))
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(10)
        .background(.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
    }
}

private struct HUDCornerMark: View {
    var body: some View {
        VStack {
            HStack {
                corner
                Spacer()
                corner.rotationEffect(.degrees(90))
            }
            Spacer()
            HStack {
                corner.rotationEffect(.degrees(-90))
                Spacer()
                corner.rotationEffect(.degrees(180))
            }
        }
        .allowsHitTesting(false)
    }

    private var corner: some View {
        Path { path in
            path.move(to: CGPoint(x: 0, y: 24))
            path.addLine(to: CGPoint(x: 0, y: 0))
            path.addLine(to: CGPoint(x: 24, y: 0))
        }
        .stroke(.cyan.opacity(0.88), lineWidth: 2)
        .frame(width: 24, height: 24)
    }
}

private struct SpaceBackground: View {
    var body: some View {
        ZStack {
            Color(red: 0.018, green: 0.027, blue: 0.07)
            RadialGradient(colors: [.indigo.opacity(0.34), .clear], center: .topLeading, startRadius: 1, endRadius: 620)
            LinearGradient(colors: [.clear, .cyan.opacity(0.04), .purple.opacity(0.10)], startPoint: .top, endPoint: .bottomTrailing)
        }
        .ignoresSafeArea()
    }
}
