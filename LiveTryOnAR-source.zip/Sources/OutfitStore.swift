import SwiftUI
import UIKit

@MainActor
final class OutfitStore: ObservableObject {
    @Published var sourceImage: UIImage?
    @Published private(set) var topTexture: UIImage?
    @Published private(set) var bottomTexture: UIImage?

    func setOutfitImage(_ image: UIImage) {
        sourceImage = image
        topTexture = image.crop(verticalRange: 0.0...0.56)
        bottomTexture = image.crop(verticalRange: 0.50...1.0)
    }
}

private extension UIImage {
    func crop(verticalRange: ClosedRange<CGFloat>) -> UIImage? {
        guard let cgImage else { return nil }
        let normalized = imageOrientation == .up ? self : normalizedImage()
        guard let normalizedCGImage = normalized.cgImage else { return nil }
        let height = CGFloat(normalizedCGImage.height)
        let width = CGFloat(normalizedCGImage.width)
        let start = max(0, min(1, verticalRange.lowerBound)) * height
        let end = max(0, min(1, verticalRange.upperBound)) * height
        let rect = CGRect(x: 0, y: start, width: width, height: max(1, end - start)).integral
        guard let cropped = normalizedCGImage.cropping(to: rect) else { return nil }
        return UIImage(cgImage: cropped, scale: normalized.scale, orientation: .up)
    }

    func normalizedImage() -> UIImage {
        guard imageOrientation != .up else { return self }
        let renderer = UIGraphicsImageRenderer(size: size)
        return renderer.image { _ in draw(in: CGRect(origin: .zero, size: size)) }
    }
}
