#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TEAM_ID="${DEVELOPMENT_TEAM:?Set DEVELOPMENT_TEAM to your Apple Developer Team ID}"
PROFILE_NAME="${PROVISIONING_PROFILE_NAME:?Set PROVISIONING_PROFILE_NAME to the installed profile name}"
BUNDLE_ID="${BUNDLE_IDENTIFIER:-com.example.LiveTryOnAR}"
CONFIGURATION="${CONFIGURATION:-Release}"
ARCHIVE_PATH="$ROOT_DIR/build/LiveTryOnAR.xcarchive"
IPA_DIR="$ROOT_DIR/build/ipa"

command -v xcodegen >/dev/null || { echo "xcodegen is required (brew install xcodegen)" >&2; exit 1; }
command -v xcodebuild >/dev/null || { echo "This script must run on macOS with Xcode installed." >&2; exit 1; }

xcodegen generate --spec "$ROOT_DIR/project.yml"
mkdir -p "$(dirname "$ARCHIVE_PATH")"
rm -rf "$ARCHIVE_PATH" "$IPA_DIR"
mkdir -p "$IPA_DIR"

xcodebuild \
  -project "$ROOT_DIR/LiveTryOnAR.xcodeproj" \
  -scheme LiveTryOnAR \
  -configuration "$CONFIGURATION" \
  -sdk iphoneos \
  -archivePath "$ARCHIVE_PATH" \
  clean archive \
  DEVELOPMENT_TEAM="$TEAM_ID" \
  PRODUCT_BUNDLE_IDENTIFIER="$BUNDLE_ID" \
  CODE_SIGN_STYLE=Manual \
  PROVISIONING_PROFILE_SPECIFIER="$PROFILE_NAME"

EXPORT_OPTIONS="$ROOT_DIR/build/ExportOptions.plist"
sed \
  -e "s|__TEAM_ID__|$TEAM_ID|g" \
  -e "s|__BUNDLE_ID__|$BUNDLE_ID|g" \
  -e "s|__PROFILE_NAME__|$PROFILE_NAME|g" \
  "$ROOT_DIR/Scripts/ExportOptions.plist.template" > "$EXPORT_OPTIONS"

xcodebuild -exportArchive \
  -archivePath "$ARCHIVE_PATH" \
  -exportPath "$IPA_DIR" \
  -exportOptionsPlist "$EXPORT_OPTIONS"

echo "IPA created at: $IPA_DIR"
