import AVFoundation
import SwiftUI
import Vision

struct SelfieTryOnView: UIViewControllerRepresentable {
    let topTexture: UIImage?
    let bottomTexture: UIImage?

    func makeUIViewController(context: Context) -> SelfieTryOnViewController {
        SelfieTryOnViewController()
    }

    func updateUIViewController(_ controller: SelfieTryOnViewController, context: Context) {
        controller.updateTextures(top: topTexture, bottom: bottomTexture)
    }
}

final class SelfieTryOnViewController: UIViewController, AVCaptureVideoDataOutputSampleBufferDelegate {
    private let session = AVCaptureSession()
    private let captureQueue = DispatchQueue(label: "com.example.LiveTryOnAR.selfie.capture")
    private let visionQueue = DispatchQueue(label: "com.example.LiveTryOnAR.selfie.vision")
    private let poseRequest = VNDetectHumanBodyPoseRequest()
    private var previewLayer: AVCaptureVideoPreviewLayer!
    private let outfitOverlay = PoseOutfitOverlayView()
    private var isProcessingFrame = false

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black
        configurePreview()
        configureCapture()
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        previewLayer.frame = view.bounds
        outfitOverlay.frame = view.bounds
    }

    func updateTextures(top: UIImage?, bottom: UIImage?) {
        outfitOverlay.topTexture = top
        outfitOverlay.bottomTexture = bottom
    }

    private func configurePreview() {
        previewLayer = AVCaptureVideoPreviewLayer(session: session)
        previewLayer.videoGravity = .resizeAspectFill
        view.layer.addSublayer(previewLayer)
        outfitOverlay.isUserInteractionEnabled = false
        outfitOverlay.backgroundColor = .clear
        view.addSubview(outfitOverlay)
    }

    private func configureCapture() {
        guard AVCaptureDevice.authorizationStatus(for: .video) != .denied else { return }
        if AVCaptureDevice.authorizationStatus(for: .video) == .notDetermined {
            AVCaptureDevice.requestAccess(for: .video) { [weak self] granted in
                guard granted else { return }
                DispatchQueue.main.async { self?.configureCapture() }
            }
            return
        }

        captureQueue.async { [weak self] in
            guard let self, !self.session.isRunning else { return }
            self.session.beginConfiguration()
            self.session.sessionPreset = .high
            defer { self.session.commitConfiguration() }

            guard let camera = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .front),
                  let input = try? AVCaptureDeviceInput(device: camera),
                  self.session.canAddInput(input) else { return }
            self.session.addInput(input)

            let output = AVCaptureVideoDataOutput()
            output.alwaysDiscardsLateVideoFrames = true
            output.setSampleBufferDelegate(self, queue: self.captureQueue)
            guard self.session.canAddOutput(output) else { return }
            self.session.addOutput(output)
            output.connection(with: .video)?.videoOrientation = .portrait
            output.connection(with: .video)?.isVideoMirrored = true
            self.session.startRunning()
        }
    }

    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        guard !isProcessingFrame, let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }
        isProcessingFrame = true
        visionQueue.async { [weak self] in
            defer { self?.isProcessingFrame = false }
            guard let self else { return }
            let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, orientation: .leftMirrored)
            do {
                try handler.perform([self.poseRequest])
                guard let observation = self.poseRequest.results?.first else {
                    DispatchQueue.main.async { self.outfitOverlay.clearPose() }
                    return
                }
                let pose = try SelfieTryOnViewController.extractPose(from: observation)
                DispatchQueue.main.async { [weak self] in self?.outfitOverlay.update(pose: pose) }
            } catch {
                DispatchQueue.main.async { self.outfitOverlay.clearPose() }
            }
        }
    }

    private static func extractPose(from observation: VNHumanBodyPoseObservation) throws -> [String: CGPoint] {
        let joints: [(String, VNHumanBodyPoseObservation.JointName)] = [
            ("leftShoulder", .leftShoulder), ("rightShoulder", .rightShoulder),
            ("leftHip", .leftHip), ("rightHip", .rightHip),
            ("leftKnee", .leftKnee), ("rightKnee", .rightKnee),
            ("leftAnkle", .leftAnkle), ("rightAnkle", .rightAnkle)
        ]
        var output: [String: CGPoint] = [:]
        for (name, joint) in joints {
            let point = try observation.recognizedPoint(joint)
            guard point.confidence > 0.35 else { continue }
            output[name] = point.location
        }
        return output
    }
}

private final class PoseOutfitOverlayView: UIView {
    var topTexture: UIImage? { didSet { setNeedsDisplay() } }
    var bottomTexture: UIImage? { didSet { setNeedsDisplay() } }
    private var pose: [String: CGPoint] = [:]

    func update(pose: [String: CGPoint]) {
        self.pose = pose
        setNeedsDisplay()
    }

    func clearPose() {
        pose = [:]
        setNeedsDisplay()
    }

    override func draw(_ rect: CGRect) {
        guard let leftShoulder = point("leftShoulder"), let rightShoulder = point("rightShoulder"),
              let leftHip = point("leftHip"), let rightHip = point("rightHip") else { return }
        let context = UIGraphicsGetCurrentContext()!
        let shirtPath = UIBezierPath()
        shirtPath.move(to: leftShoulder)
        shirtPath.addLine(to: rightShoulder)
        shirtPath.addLine(to: rightHip)
        shirtPath.addLine(to: leftHip)
        shirtPath.close()
        context.saveGState()
        shirtPath.addClip()
        if let image = topTexture?.cgImage {
            context.draw(image, in: shirtPath.bounds.insetBy(dx: -12, dy: -12))
        } else {
            UIColor.systemBlue.withAlphaComponent(0.55).setFill()
            shirtPath.fill()
        }
        context.restoreGState()
        UIColor.white.withAlphaComponent(0.8).setStroke()
        shirtPath.lineWidth = 2
        shirtPath.stroke()

        drawLeg(from: leftHip, via: point("leftKnee"), to: point("leftAnkle"), in: context)
        drawLeg(from: rightHip, via: point("rightKnee"), to: point("rightAnkle"), in: context)
    }

    private func drawLeg(from hip: CGPoint, via knee: CGPoint?, to ankle: CGPoint?, in context: CGContext) {
        guard let knee, let ankle else { return }
        let path = UIBezierPath()
        path.move(to: hip)
        path.addLine(to: knee)
        path.addLine(to: ankle)
        path.lineCapStyle = .round
        path.lineJoinStyle = .round
        path.lineWidth = max(24, bounds.width * 0.07)
        if let image = bottomTexture {
            UIColor(patternImage: image).withAlphaComponent(0.70).setStroke()
        } else {
            UIColor.systemIndigo.withAlphaComponent(0.65).setStroke()
        }
        path.stroke()
        UIColor.white.withAlphaComponent(0.75).setStroke()
        path.lineWidth = 1.5
        path.stroke()
    }

    private func point(_ name: String) -> CGPoint? {
        guard let normalized = pose[name] else { return nil }
        // Vision uses a bottom-left origin; the preview is mirrored by the capture connection.
        return CGPoint(x: normalized.x * bounds.width, y: (1 - normalized.y) * bounds.height)
    }
}
